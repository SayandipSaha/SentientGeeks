﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagement.Models
{
    public class DeleteRequest
    {
        public List<int> Ids { get; set; } 
        public int Id { get; set; } 
    }

}
