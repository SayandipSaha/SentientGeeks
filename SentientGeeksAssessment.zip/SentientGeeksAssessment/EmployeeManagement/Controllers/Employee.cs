﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace EmployeeManagement.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly AppDbContext _context;

        public EmployeeController(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var employees = await _context.Employees.ToListAsync();
            return View(employees);
        }

        public IActionResult Create()
        {
            return PartialView("_Create", new Employee());
        }

        [HttpPost]
        public IActionResult Create(Employee employee)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    
                    bool employeeExists = _context.Employees.Any(e => e.Name == employee.Name && e.Phone == employee.Phone);
                    if (employeeExists)
                    {
                        return Json(new { success = false, message = "Employee with the same name and phone number already exists." });
                    }

                    _context.Employees.Add(employee);
                    _context.SaveChanges();
                    return Json(new { success = true });
                }
                catch (Exception ex)
                {
                    return Json(new { success = false, message = ex.Message });
                }
            }

            var errorMessages = ModelState.Where(m => m.Value.Errors.Count > 0)
                                          .ToDictionary(
                                              kvp => kvp.Key,
                                              kvp => kvp.Value.Errors.First().ErrorMessage
                                          );

            return Json(new { success = false, message = "Validation failed", errors = errorMessages });
        }



        public IActionResult Edit(int id)
        {
            var employee = _context.Employees.Find(id);
            if (employee == null)
            {
                return NotFound();
            }
            return PartialView("_Edit", employee);
        }


        [HttpPost]
        public IActionResult Edit(Employee employee)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var existingEmployee = _context.Employees.AsNoTracking().FirstOrDefault(e => e.Id == employee.Id);
                    if (existingEmployee == null)
                    {
                        return Json(new { success = false, message = "Employee not found" });
                    }

                    bool hasChanges = existingEmployee.Name != employee.Name ||
                                      existingEmployee.Email != employee.Email ||
                                      existingEmployee.Address != employee.Address ||
                                      existingEmployee.Phone != employee.Phone;

                    if (!hasChanges)
                    {
                        return Json(new { success = false, message = "No changes detected. Please modify the details before saving." });
                    }

                   
                    bool duplicateExists = _context.Employees.Any(e => e.Id != employee.Id && e.Name == employee.Name && e.Phone == employee.Phone);
                    if (duplicateExists)
                    {
                        return Json(new { success = false, message = "An employee with the same name and phone number already exists." });
                    }

                    
                    _context.Employees.Update(employee);
                    _context.SaveChanges();

                    return Json(new { success = true });
                }
                catch (Exception ex)
                {
                    return Json(new { success = false, message = ex.Message });
                }
            }

            var errorMessages = ModelState.Where(m => m.Value.Errors.Count > 0)
                                          .ToDictionary(
                                              kvp => kvp.Key,
                                              kvp => kvp.Value.Errors.First().ErrorMessage
                                          );

            return Json(new { success = false, message = "Validation failed", errors = errorMessages });
        }





        [HttpPost]
        public async Task<IActionResult> Delete([FromBody] DeleteRequest request)
        {
            if (request?.Id == null || request.Id == 0)
            {
                return Json(new { success = false, message = "Invalid request. Employee ID is missing." });
            }

            var employee = await _context.Employees.FindAsync(request.Id);
            if (employee == null)
            {
                return Json(new { success = false, message = "Employee not found." });
            }

            _context.Employees.Remove(employee);
            await _context.SaveChangesAsync();

            return Json(new { success = true });
        }

        [HttpPost]
        public async Task<IActionResult> DeleteSelected([FromBody] DeleteRequest request)
        {
            if (request?.Ids == null || !request.Ids.Any())
            {
                return Json(new { success = false, message = "No records selected." });
            }

            var employeesToDelete = await _context.Employees
                .Where(e => request.Ids.Contains(e.Id))
                .ToListAsync();

            if (!employeesToDelete.Any())
            {
                return Json(new { success = false, message = "No records found." });
            }

            _context.Employees.RemoveRange(employeesToDelete);
            await _context.SaveChangesAsync();

            return Json(new { success = true });
        }
    }
}
